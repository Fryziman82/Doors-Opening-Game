import pygame
from moviepy.editor import VideoFileClip
import sys

pygame.init()

# Установка параметров окна
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Игра с открытием двери")

# Уровни игры с путями к изображениям фона
levels = [
    {"door_x": 350, "door_y": 250, "door_width": 100, "door_height": 200, "background": "resources/background1.jpg"},
    {"door_x": 300, "door_y": 200, "door_width": 150, "door_height": 250, "background": "resources/background2.jpg"},
    {"door_x": 250, "door_y": 150, "door_width": 200, "door_height": 300, "background": "resources/background3.jpg"},
    {"door_x": 200, "door_y": 100, "door_width": 250, "door_height": 350, "background": "resources/background4.jpg"},
    {"door_x": 150, "door_y": 50, "door_width": 300, "door_height": 400, "background": "resources/background5.jpg"},
]

# Класс для представления двери
class Door:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.image_closed = pygame.image.load('resources/close.jpg')  # Изображение закрытой двери
        self.image_closed = pygame.transform.scale(self.image_closed, (width, height))
        self.image_open = pygame.image.load('resources/open.jpg')  # Изображение открытой двери
        self.image_open = pygame.transform.scale(self.image_open, (width, height))
        self.is_open = False

    def open(self):
        self.is_open = True

    def draw(self):
        if self.is_open:
            screen.blit(self.image_open, (self.x, self.y))  # Отображение открытой двери
        else:
            screen.blit(self.image_closed, (self.x, self.y))  # Отображение закрытой двери

# Загрузка звукового файла
door_open_sound = pygame.mixer.Sound('resources/door_open.wav')

# Создание дверей для каждого уровня
doors = [Door(level["door_x"], level["door_y"], level["door_width"], level["door_height"]) for level in levels]

# Основной цикл игры
current_level = 0
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    # Если пользователь нажимает "пробел", открываем дверь
    if keys[pygame.K_SPACE]:
        if not doors[current_level].is_open:
            door_open_sound.play()
            doors[current_level].open()

    # Отрисовка фона текущего уровня
    background_image = pygame.image.load(levels[current_level]["background"])
    background_image = pygame.transform.scale(background_image, (width, height))
    screen.blit(background_image, (0, 0))

    # Отрисовка дверей
    doors[current_level].draw()  # Отрисовываем только дверь на текущем уровне
    
    pygame.display.flip()


    # Переход на следующий уровень после открытия двери
    if doors[current_level].is_open:
        pygame.time.delay(3000)  # Задержка для анимации открытой двери
        if current_level < len(doors) - 1:  # Если это не последний уровень
            current_level += 1
            doors[current_level - 1].is_open = False  # Закрываем дверь после перехода на следующий уровень
        else:
            pygame.time.delay(1000)  # Задержка после открытия последней двери
            running = False  # Завершаем игру после открытия последней двери

# Загрузка видео
video_clip = VideoFileClip("https://te.legra.ph/file/03a971d45a9961df50769.mp4")

# Воспроизведение видео в том же окне
video_clip.preview()

pygame.quit()
sys.exit()
